package infnet.edu.br.appAT;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppAtApplicationTests {

	@Test
	void contextLoads() {
	}

}
