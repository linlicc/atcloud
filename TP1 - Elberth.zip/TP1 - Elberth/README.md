# Desenvolvimento-Java-20E4-21E1
Repositório do TP1 da disciplina de Fundamentos da Programação

## Começando
Para executar os projetos, será necessário instalar os seguintes programas:

JDK 8 | Eclipse IDE for Java EE Developers

## Desenvolvimento
Para iniciar o desenvolvimento, é necessário clonar o projeto do GitHub num diretório de sua preferência:
git clone https://github.com/linlicc/TP1_java.git
